# Mini-Lab CEH Practical — Cesar

Entorno local con Docker para practicar 8 de los 20 retos tipo examen.
Diseñado para correr en una VM de Kali (o tu máquina con Docker) atacando
contenedores en la red `10.10.10.0/24`.

## Requisitos

- Docker + Docker Compose
- Python 3 con Pillow (`pip install pillow --break-system-packages`)
- mosquitto-clients (`sudo apt install mosquitto-clients`)
- VeraCrypt (opcional, solo para el reto 14 — ver `scripts/gen_veracrypt_note.md`)

## Levantar el lab

```bash
cd ceh-minilab/scripts
chmod +x setup_flags.sh
./setup_flags.sh

cd ..
python3 scripts/gen_stego.py
python3 scripts/gen_xor.py

docker compose up -d

# Espera ~15s a que mosquitto levante, luego:
bash scripts/publish_mqtt_flag.sh
```

Verifica que todo esté arriba: `docker compose ps`

## Mapa de retos vs. servicios

| # | Reto (del set de 20) | Servicio / IP | Herramienta sugerida |
|---|---|---|---|
| 4 | Servicio en puerto no estándar | `10.10.10.14:13337` | `nmap -sV -p13337 10.10.10.14` |
| 5 | Share SMB anónimo con flag | `10.10.10.12` | `smbclient -L //10.10.10.12 -N` → `smbclient //10.10.10.12/public -N` |
| 6 | Versión MySQL + root sin password | `10.10.10.11:3306` | `nmap -sV -p3306 --script mysql-info 10.10.10.11` luego `mysql -h 10.10.10.11 -u root` |
| 9 | SQLi en app web (DVWA) | `http://10.10.10.10:8080` (user: `admin`/`password`, subir DVWA security a "low") | Burp Suite / sqlmap |
| 11 | File upload → RCE | Mismo DVWA, módulo "File Upload" | sube `shell.php`, accede vía navegador |
| 14 | VeraCrypt | `flags/vault.vc` (archivo local, no red) | `veracrypt --text --password-list=flags/wordlist.txt` |
| 15 | Esteganografía LSB | `flags/stego_challenge.png` | `zsteg`, `stegseek`, o script Python propio de extracción LSB |
| 16 | XOR de un byte | `flags/xor_challenge.bin` | CyberChef (brute force XOR) o script Python |
| 18 | MQTT sin autenticación | `10.10.10.13:1883` | `mosquitto_sub -h 10.10.10.13 -t '#' -v` |

## Notas por reto

**Reto 4 (puerto raro):** el banner expone una versión falsa "2.3.1-beta" —
el objetivo es que practiques banner grabbing y no asumas que es un puerto conocido.

**Reto 5 (SMB):** usuario/contraseña del contenedor son `user`/`pass`, pero el
share `public` permite acceso **anónimo** de lectura — ese es el punto a descubrir.

**Reto 6 (MySQL):** `MYSQL_ALLOW_EMPTY_PASSWORD=yes` simula una mala práctica común.
Conéctate con `mysql -h 10.10.10.11 -u root` (sin password) y confirma la versión
con `SELECT VERSION();`.

**Retos 9 y 11 (DVWA):** tras loguearte, ve a "DVWA Security" y bájalo a "low" para
la primera pasada, luego sube a "medium"/"high" para repetir con más dificultad
(así simulas distintos niveles del examen real).

**Reto 14 (VeraCrypt):** sigue `scripts/gen_veracrypt_note.md` para generarlo —
requiere el binario VeraCrypt en tu máquina anfitriona.

**Reto 15 (stego):** el script oculta la flag en los bits menos significativos
del canal rojo. Para resolverlo sin el script, usa `zsteg stego_challenge.png`
o escribe tu propio extractor LSB en Python.

**Reto 16 (XOR):** la clave es un solo byte (1-255). CyberChef tiene un
"XOR Brute Force" que prueba las 255 claves y te muestra cuál produce texto legible.

**Reto 18 (MQTT):** el tópico no se anuncia — hay que suscribirse a `#` (wildcard)
para descubrirlo, tal como en el examen real donde no te dicen el tópico exacto.

## Apagar el lab

```bash
docker compose down -v
```

## Siguiente nivel

Cuando domines estos 8, podemos sumar al lab:
- Un AD mínimo (Samba-AD) para el reto 7 (enumeración de usuarios por RPC null session)
- Un WordPress vulnerable para el reto 8 (fingerprinting de CMS)
- Un endpoint XML para el reto 12 (XXE → LFI)
