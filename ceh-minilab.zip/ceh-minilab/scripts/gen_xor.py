#!/usr/bin/env python3
"""
Genera un archivo cifrado con XOR de clave de un solo byte.
Uso: python3 gen_xor.py
"""
import random

PLAINTEXT = b"CEH{x0r_1s_n0t_3ncrypt10n_2026}"
OUT = "../flags/xor_challenge.bin"

def xor_encrypt(data: bytes, key: int) -> bytes:
    return bytes([b ^ key for b in data])

if __name__ == "__main__":
    key = random.randint(1, 255)
    cipher = xor_encrypt(PLAINTEXT, key)
    with open(OUT, "wb") as f:
        f.write(cipher)
    print(f"[+] Archivo cifrado generado en {OUT}")
    print(f"[+] Clave usada (solo para el instructor): {key}")
    print(f"[+] Texto plano original: {PLAINTEXT.decode()}")
