#!/bin/bash
# Prepara los directorios de flags antes de levantar docker-compose
set -e

mkdir -p ../flags/smb_share
mkdir -p ../flags/weird_service

# Reto 5: flag en share SMB anónimo
echo "CEH{sm4ll_sh4res_b1g_pr0bl3ms_2026}" > ../flags/smb_share/flag.txt

# Reto 4: servicio en puerto no estándar (13337) sirviendo un banner con versión falsa
cat > ../flags/weird_service/banner.txt <<EOF
SimpleHTTP/0.6 Python/3.11.4
X-Service-Name: InternalReportingTool
X-Service-Version: 2.3.1-beta
EOF
echo "CEH{p0rt_13337_1s_n0t_r4nd0m_2026}" > ../flags/weird_service/flag.txt

echo "[+] Flags y directorios listos en ../flags/"
