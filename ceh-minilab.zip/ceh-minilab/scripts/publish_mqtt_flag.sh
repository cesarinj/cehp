#!/bin/bash
# Ejecutar DESPUES de levantar docker-compose (mosquitto corriendo en 10.10.10.13:1883)
# Requiere mosquitto-clients instalado: sudo apt install mosquitto-clients
set -e

BROKER="10.10.10.13"
TOPIC="iot/devices/thermostat01/status"
FLAG="CEH{mqtt_wh1sp3rs_1n_th3_d4rk_2026}"

mosquitto_pub -h "$BROKER" -t "$TOPIC" -m "$FLAG" -r

echo "[+] Flag publicada (retained) en el topico: $TOPIC"
echo "[+] El estudiante debe descubrir el topico con: mosquitto_sub -h $BROKER -t '#' -v"
