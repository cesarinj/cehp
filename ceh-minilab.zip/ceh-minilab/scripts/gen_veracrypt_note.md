# Reto 14 — Contenedor VeraCrypt

VeraCrypt no se puede generar vía script puro sin tener el binario de VeraCrypt instalado
en la máquina que arma el lab. Pasos manuales (5 minutos):

1. Instala VeraCrypt en tu máquina anfitriona (la que arma el lab, no la víctima):
   `sudo apt install veracrypt` (o descarga desde veracrypt.fr)

2. Crea un volumen de archivo:
   ```
   veracrypt --create ../flags/vault.vc \
     --volume-type=normal --size=10M --encryption=AES \
     --hash=sha512 --filesystem=FAT --pim=0 \
     --password=summer2024 --keyfiles= --random-source=/dev/urandom
   ```

3. Móntalo, copia la flag adentro, desmóntalo:
   ```
   mkdir -p /tmp/vcmount
   veracrypt ../flags/vault.vc /tmp/vcmount --password=summer2024 --pim=0 -t
   echo "CEH{v3r4crypt_h1dd3n_tr34sur3_2026}" > /tmp/vcmount/secret.txt
   veracrypt -d /tmp/vcmount -t
   ```

4. Entrega al estudiante `vault.vc` + una wordlist de 10-15 contraseñas que incluya
   `summer2024` en algún punto (no la primera, para que practique con John/Hashcat
   o fuerza bruta de VeraCrypt: `veracrypt --text --keyfiles= --password-list=wordlist.txt ...`).

Wordlist sugerida (guárdala como `flags/wordlist.txt`):
```
password123
Summer2023
summer2024
Winter2024!
Company2025
admin123
Welcome1
Qwerty2024
```
