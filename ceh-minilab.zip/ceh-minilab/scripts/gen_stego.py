#!/usr/bin/env python3
"""
Genera una imagen PNG con un mensaje oculto usando LSB steganography.
Requiere: pip install pillow --break-system-packages
Uso: python3 gen_stego.py
"""
from PIL import Image
import random

FLAG = "CEH{st3g0_1s_fun_2026}"
OUT = "../flags/stego_challenge.png"

def encode_lsb(image_path_out, message, width=400, height=300):
    img = Image.new("RGB", (width, height))
    pixels = img.load()
    for x in range(width):
        for y in range(height):
            pixels[x, y] = (
                random.randint(0, 255),
                random.randint(0, 255),
                random.randint(0, 255),
            )

    binary_msg = "".join(format(ord(c), "08b") for c in message) + "11111110"  # terminador
    idx = 0
    for y in range(height):
        for x in range(width):
            if idx >= len(binary_msg):
                break
            r, g, b = pixels[x, y]
            r = (r & ~1) | int(binary_msg[idx])
            pixels[x, y] = (r, g, b)
            idx += 1
        if idx >= len(binary_msg):
            break

    img.save(image_path_out)
    print(f"[+] Flag oculta en {image_path_out}")
    print(f"[+] Flag real (para verificación del instructor): {message}")

if __name__ == "__main__":
    encode_lsb(OUT, FLAG)
